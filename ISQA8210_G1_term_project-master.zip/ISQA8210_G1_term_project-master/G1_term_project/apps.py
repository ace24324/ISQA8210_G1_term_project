from django.apps import AppConfig


class G1TermProjectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'G1_term_project'
